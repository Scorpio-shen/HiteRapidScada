﻿namespace Scada.Comm.Devices.Mqtt.Config
{
    public enum PubBehavior
    {
        OnChange,
        OnAlways
    }
}
