﻿namespace Scada.Comm.Devices.Mqtt.Config
{
    public enum CmdType
    {
        St=0,
        BinTxt,
        BinHex,
        Req
    }
}
